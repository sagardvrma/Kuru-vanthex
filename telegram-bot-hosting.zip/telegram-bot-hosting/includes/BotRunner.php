<?php
class BotRunner {
    private $bot_id, $bot_token, $bot_name, $language, $code, $pid_file, $log_file;
    
    public function __construct($bot_id, $bot_token, $bot_name, $language, $code) {
        $this->bot_id = $bot_id;
        $this->bot_token = $bot_token;
        $this->bot_name = $bot_name;
        $this->language = $language;
        $this->code = $code;
        $this->pid_file = __DIR__ . "/../bots/pid_{$bot_id}.txt";
        $this->log_file = __DIR__ . "/../logs/bot_{$bot_id}.log";
        if(!is_dir(__DIR__ . "/../bots")) mkdir(__DIR__ . "/../bots", 0777, true);
        if(!is_dir(__DIR__ . "/../logs")) mkdir(__DIR__ . "/../logs", 0777, true);
    }
    
    public function deploy() { return $this->start(); }
    
    public function start() {
        if($this->isRunning()) return false;
        $filename = $this->getFilename();
        $code = $this->processCode();
        file_put_contents($filename, $code);
        $cmd = $this->getCommand($filename);
        if(PHP_OS_FAMILY === 'Windows') $proc = popen("start /B $cmd", "r");
        else $proc = shell_exec("nohup $cmd > /dev/null 2>&1 & echo $!");
        $pid = trim($proc);
        file_put_contents($this->pid_file, $pid);
        $this->updateStatus('running', $pid);
        return true;
    }
    
    public function stop() {
        if(!$this->isRunning()) return false;
        $pid = file_get_contents($this->pid_file);
        if(PHP_OS_FAMILY === 'Windows') exec("taskkill /F /PID $pid");
        else exec("kill -9 $pid");
        unlink($this->pid_file);
        $this->updateStatus('stopped', null);
        return true;
    }
    
    public function restart() { $this->stop(); sleep(2); return $this->start(); }
    public function isRunning() { return file_exists($this->pid_file) && file_get_contents($this->pid_file) && posix_kill(file_get_contents($this->pid_file), 0); }
    public function getLogs($lines = 100) { return file_exists($this->log_file) ? implode('', array_slice(file($this->log_file), -$lines)) : "No logs"; }
    
    private function getFilename() { return __DIR__ . "/../bots/bot_{$this->bot_id}." . $this->getExtension(); }
    private function getExtension() { $ext = ['python'=>'py','nodejs'=>'js','php'=>'php','go'=>'go','ruby'=>'rb','java'=>'java','bjs'=>'js']; return $ext[$this->language] ?? 'py'; }
    private function getCommand($filename) { $cmds = ['python'=>"python3 $filename",'nodejs'=>"node $filename",'php'=>"php $filename",'bjs'=>"node $filename"]; return $cmds[$this->language] ?? "python3 $filename"; }
    private function processCode() { $code = $this->code; if($this->language == 'python' && strpos($code, 'infinity_polling') === false) $code .= "\n\nif __name__ == '__main__':\n    bot.infinity_polling()"; return $code; }
    private function updateStatus($status, $pid) { global $conn; $stmt = $conn->prepare("UPDATE bots SET status = ?, pid = ? WHERE id = ?"); $stmt->bind_param("sii", $status, $pid, $this->bot_id); $stmt->execute(); if($status == 'running') $conn->query("UPDATE bots SET start_time = NOW() WHERE id = {$this->bot_id}"); }
}
?>