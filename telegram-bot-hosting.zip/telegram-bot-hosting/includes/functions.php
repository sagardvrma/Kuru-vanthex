<?php
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

function getUserPlan($user_id) {
    global $conn, $PLANS;
    $result = $conn->query("SELECT plan, plan_expiry FROM users WHERE id = $user_id");
    $user = $result->fetch_assoc();
    if($user && $user['plan_expiry'] && strtotime($user['plan_expiry']) < time()) {
        $conn->query("UPDATE users SET plan = 'free' WHERE id = $user_id");
        return 'free';
    }
    return $user ? $user['plan'] : 'free';
}

function getPlanLimits($user_id) {
    global $PLANS;
    $plan = getUserPlan($user_id);
    return $PLANS[$plan];
}

function generateAPIKey() {
    return 'vantex_' . bin2hex(random_bytes(32));
}

function logAdminAction($admin_id, $action, $details) {
    global $conn;
    $ip = $_SERVER['REMOTE_ADDR'];
    $conn->query("INSERT INTO admin_logs (admin_id, action, details, ip) VALUES ($admin_id, '$action', '$details', '$ip')");
}

function formatSize($bytes) {
    if($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function getBotStatus($bot_id) {
    $pid_file = __DIR__ . "/../bots/pid_{$bot_id}.txt";
    if(file_exists($pid_file)) {
        $pid = file_get_contents($pid_file);
        if($pid && posix_kill($pid, 0)) return 'running';
    }
    return 'stopped';
}
?>