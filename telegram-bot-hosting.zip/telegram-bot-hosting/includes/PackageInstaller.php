<?php
class PackageInstaller {
    private $language;
    private $user_id;
    
    public function __construct($language, $user_id) {
        $this->language = $language;
        $this->user_id = $user_id;
    }
    
    public function install($package) {
        global $conn;
        
        $cmd = $this->getInstallCommand($package);
        if(!$cmd) return ['success' => false, 'error' => 'Unsupported language'];
        
        $output = shell_exec($cmd . ' 2>&1');
        $success = $this->checkInstallSuccess($output);
        
        if($success) {
            $conn->query("INSERT INTO installed_packages (user_id, package_name) VALUES ({$this->user_id}, '$package')");
        }
        
        return ['success' => $success, 'output' => $output];
    }
    
    public function uninstall($package) {
        global $conn;
        
        $cmd = $this->getUninstallCommand($package);
        if(!$cmd) return ['success' => false, 'error' => 'Unsupported language'];
        
        $output = shell_exec($cmd . ' 2>&1');
        $success = strpos($output, 'Successfully uninstalled') !== false;
        
        if($success) {
            $conn->query("DELETE FROM installed_packages WHERE user_id = {$this->user_id} AND package_name = '$package'");
        }
        
        return ['success' => $success, 'output' => $output];
    }
    
    public function listInstalled() {
        global $conn;
        $result = $conn->query("SELECT * FROM installed_packages WHERE user_id = {$this->user_id} ORDER BY installed_at DESC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    private function getInstallCommand($package) {
        $commands = [
            'python' => "pip3 install $package",
            'nodejs' => "npm install -g $package",
            'php' => "composer require $package",
            'ruby' => "gem install $package",
            'go' => "go get $package"
        ];
        return $commands[$this->language] ?? null;
    }
    
    private function getUninstallCommand($package) {
        $commands = [
            'python' => "pip3 uninstall -y $package",
            'nodejs' => "npm uninstall -g $package",
            'php' => "composer remove $package",
            'ruby' => "gem uninstall $package"
        ];
        return $commands[$this->language] ?? null;
    }
    
    private function checkInstallSuccess($output) {
        $success_patterns = [
            'Successfully installed',
            'added',
            'Installation completed',
            'installed successfully'
        ];
        
        foreach($success_patterns as $pattern) {
            if(stripos($output, $pattern) !== false) return true;
        }
        return false;
    }
}
?>