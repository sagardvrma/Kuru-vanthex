<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
$cpu = round(sys_getloadavg()[0] * 100 / 4, 1);
$ram = round(memory_get_usage() / 1048576, 2);
$ping = round((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000);
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$total_bots = $conn->query("SELECT COUNT(*) FROM bots")->fetch_row()[0];
$running_bots = $conn->query("SELECT COUNT(*) FROM bots WHERE status = 'running'")->fetch_row()[0];
echo json_encode(['cpu'=>$cpu, 'ram'=>$ram, 'ping'=>$ping, 'total_users'=>$total_users, 'total_bots'=>$total_bots, 'running_bots'=>$running_bots]);
?>