<?php
require_once '../includes/config.php';
require_once '../includes/BotRunner.php';
if(!isLoggedIn()) { http_response_code(401); exit(); }
$bot_id = (int)$_GET['id'];
$bot = $conn->query("SELECT * FROM bots WHERE id = $bot_id AND user_id = {$_SESSION['user_id']}")->fetch_assoc();
if($bot) { $runner = new BotRunner($bot_id, $bot['bot_token'], $bot['bot_name'], $bot['language'], $bot['code']); $runner->restart(); }
header("Location: ../dashboard.php");
?>