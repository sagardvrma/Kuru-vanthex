<?php
require_once '../includes/config.php';
require_once '../includes/BotRunner.php';
if(!isLoggedIn()) { http_response_code(401); exit(); }
$bot_id = (int)$_GET['id'];
$bot = $conn->query("SELECT * FROM bots WHERE id = $bot_id AND user_id = {$_SESSION['user_id']}")->fetch_assoc();
if($bot) {
    $runner = new BotRunner($bot_id, $bot['bot_token'], $bot['bot_name'], $bot['language'], $bot['code']);
    echo "<!DOCTYPE html><html><head><title>Logs - {$bot['bot_name']}</title><style>body{background:#1e1e1e;color:#d4d4d4;font-family:monospace;padding:20px;}</style></head><body>";
    echo "<h2>Logs for {$bot['bot_name']}</h2><pre>" . htmlspecialchars($runner->getLogs(500)) . "</pre>";
    echo "<a href='../dashboard.php' style='color:#6366f1;'>Back to Dashboard</a></body></html>";
} else header("Location: ../dashboard.php");
?>