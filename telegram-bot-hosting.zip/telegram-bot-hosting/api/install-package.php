<?php
require_once '../includes/config.php';
if(!isLoggedIn()) { http_response_code(403); exit(); }
$plan = getUserPlan($_SESSION['user_id']);
if($plan == 'free') { echo json_encode(['success'=>false, 'error'=>'Premium required for package installation']); exit(); }

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['package'])) {
    $package = $_POST['package'];
    $language = $_POST['language'] ?? 'python';
    
    if($language == 'python') {
        $output = shell_exec("pip3 install $package 2>&1");
        $success = strpos($output, 'Successfully installed') !== false;
    } elseif($language == 'nodejs') {
        $output = shell_exec("npm install -g $package 2>&1");
        $success = strpos($output, 'added') !== false;
    } elseif($language == 'php') {
        $output = shell_exec("composer require $package 2>&1");
        $success = strpos($output, 'Installation completed') !== false;
    } else {
        $output = shell_exec("pip3 install $package 2>&1");
        $success = strpos($output, 'Successfully installed') !== false;
    }
    
    if($success) {
        $conn->query("INSERT INTO installed_packages (user_id, package_name, version) VALUES ({$_SESSION['user_id']}, '$package', 'latest')");
        echo json_encode(['success'=>true, 'output'=>$output]);
    } else {
        echo json_encode(['success'=>false, 'output'=>$output, 'error'=>'Installation failed']);
    }
} else {
    echo json_encode(['success'=>false, 'error'=>'No package specified']);
}
?>