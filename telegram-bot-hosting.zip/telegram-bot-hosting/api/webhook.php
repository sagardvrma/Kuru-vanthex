<?php
require_once '../includes/config.php';

$content = file_get_contents('php://input');
$update = json_decode($content, true);

if(isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    $text = $update['message']['text'] ?? '';
    $user_id = $update['message']['from']['id'] ?? 0;
    
    // Check if user exists in database
    $user = $conn->query("SELECT * FROM users WHERE telegram_id = $user_id")->fetch_assoc();
    
    if(!$user) {
        // Auto register new user
        $username = $update['message']['from']['username'] ?? 'user_' . $user_id;
        $api_key = generateAPIKey();
        $conn->query("INSERT INTO users (username, telegram_id, api_key) VALUES ('$username', $user_id, '$api_key')");
        $user_id_db = $conn->insert_id;
    }
    
    // Handle commands
    if($text == '/start') {
        $response = "Welcome to " . SITE_NAME . "!\n\nSend /help to see available commands.";
        file_get_contents("https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage?chat_id=$chat_id&text=" . urlencode($response));
    } elseif($text == '/help') {
        $response = "Available commands:\n/start - Start bot\n/help - Show help\n/status - Check bot status\n/mybots - List your bots";
        file_get_contents("https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage?chat_id=$chat_id&text=" . urlencode($response));
    } elseif($text == '/status') {
        $total_bots = $conn->query("SELECT COUNT(*) FROM bots")->fetch_row()[0];
        $response = "Bot Server Status:\n✅ Online\nTotal Bots: $total_bots\nUptime: 99.9%";
        file_get_contents("https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage?chat_id=$chat_id&text=" . urlencode($response));
    }
}

echo "OK";
?>