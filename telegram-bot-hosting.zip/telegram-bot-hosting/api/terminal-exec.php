<?php
require_once '../includes/config.php';
if(!isLoggedIn()) { http_response_code(403); exit(); }
$plan = getUserPlan($_SESSION['user_id']);
if($plan == 'free') { echo "Premium required for terminal access!"; exit(); }
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cmd'])) {
    $cmd = $_POST['cmd'];
    $parts = explode(' ', $cmd);
    $base_cmd = $parts[0];
    $allowed = ['ls','pwd','whoami','uptime','ps','df','free','python3','node','php','pip','npm','git','help','clear'];
    if($base_cmd == 'help') {
        echo "Available: ls, pwd, whoami, uptime, ps, df, free, python3, node, php, pip, npm, git, clear";
        exit();
    }
    if(in_array($base_cmd, $allowed)) {
        $output = shell_exec($cmd . ' 2>&1');
        echo htmlspecialchars($output ?: "Command executed");
    } else echo "Error: Command not allowed!";
}
?>