<?php
require_once '../includes/config.php';
if(!isLoggedIn() || !isAdmin()) { http_response_code(403); exit(); }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = $_POST['message'];
    $type = $_POST['type'] ?? 'all';
    
    if($type == 'all') {
        $bots = $conn->query("SELECT bot_token FROM bots");
    } elseif($type == 'running') {
        $bots = $conn->query("SELECT bot_token FROM bots WHERE status = 'running'");
    } else {
        $bots = $conn->query("SELECT bot_token FROM bots WHERE user_id = " . (int)$type);
    }
    
    $sent = 0;
    $failed = 0;
    
    while($bot = $bots->fetch_assoc()) {
        $url = "https://api.telegram.org/bot{$bot['bot_token']}/sendMessage";
        $data = ['chat_id' => '@' . SITE_NAME, 'text' => $message, 'parse_mode' => 'HTML'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if($http_code == 200) $sent++;
        else $failed++;
        usleep(50000);
    }
    
    echo json_encode(['success' => true, 'sent' => $sent, 'failed' => $failed]);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>