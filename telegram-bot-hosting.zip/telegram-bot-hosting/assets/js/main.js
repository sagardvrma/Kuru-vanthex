// ==================== GLOBAL FUNCTIONS ====================

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
        </div>
        <div class="toast-message">${message}</div>
        <div class="toast-close"><i class="fas fa-times"></i></div>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
    
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    });
}

// Show loading overlay
function showLoading() {
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.id = 'loadingOverlay';
    overlay.innerHTML = '<div class="spinner"></div><p>Loading...</p>';
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if(overlay) overlay.remove();
}

// Format file size
function formatFileSize(bytes) {
    if(bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Get time ago
function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if(interval > 1) return interval + ' years ago';
    
    interval = Math.floor(seconds / 2592000);
    if(interval > 1) return interval + ' months ago';
    
    interval = Math.floor(seconds / 86400);
    if(interval > 1) return interval + ' days ago';
    
    interval = Math.floor(seconds / 3600);
    if(interval > 1) return interval + ' hours ago';
    
    interval = Math.floor(seconds / 60);
    if(interval > 1) return interval + ' minutes ago';
    
    return Math.floor(seconds) + ' seconds ago';
}

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Failed to copy!', 'error');
    });
}

// Confirm dialog
function confirmDialog(message, callback) {
    const modal = document.createElement('div');
    modal.className = 'confirm-modal';
    modal.innerHTML = `
        <div class="confirm-modal-content">
            <div class="confirm-modal-header">
                <h4>Confirm Action</h4>
                <i class="fas fa-times close-modal"></i>
            </div>
            <div class="confirm-modal-body">
                <p>${message}</p>
            </div>
            <div class="confirm-modal-footer">
                <button class="btn btn-secondary cancel-btn">Cancel</button>
                <button class="btn btn-primary confirm-btn">Confirm</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    setTimeout(() => modal.classList.add('show'), 100);
    
    const close = () => {
        modal.classList.remove('show');
        setTimeout(() => modal.remove(), 300);
    };
    
    modal.querySelector('.close-modal').addEventListener('click', close);
    modal.querySelector('.cancel-btn').addEventListener('click', close);
    modal.querySelector('.confirm-btn').addEventListener('click', () => {
        close();
        callback();
    });
}

// AJAX request
async function ajax(url, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    };
    
    if(data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        const result = await response.json();
        return result;
    } catch(error) {
        console.error('AJAX Error:', error);
        return { success: false, error: error.message };
    }
}

// ==================== DASHBOARD FUNCTIONS ====================

// Load dashboard stats
async function loadDashboardStats() {
    const stats = await ajax('api/get-stats.php');
    if(stats.success) {
        document.getElementById('totalBots').textContent = stats.total_bots;
        document.getElementById('runningBots').textContent = stats.running_bots;
        document.getElementById('totalUsers').textContent = stats.total_users;
        document.getElementById('premiumUsers').textContent = stats.premium_users;
    }
}

// Load system status
async function loadSystemStatus() {
    const status = await ajax('api/system-info.php');
    if(status) {
        document.getElementById('cpu').textContent = status.cpu;
        document.getElementById('ram').textContent = status.ram;
        document.getElementById('disk').textContent = status.disk;
        document.getElementById('ping').textContent = status.ping;
    }
}

// ==================== BOT MANAGEMENT ====================

// Start bot
async function startBot(botId) {
    showLoading();
    const result = await ajax(`api/start.php?id=${botId}`, 'POST');
    hideLoading();
    if(result.success) {
        showToast('Bot started successfully!', 'success');
        setTimeout(() => location.reload(), 1000);
    } else {
        showToast(result.error || 'Failed to start bot', 'error');
    }
}

// Stop bot
async function stopBot(botId) {
    showLoading();
    const result = await ajax(`api/stop.php?id=${botId}`, 'POST');
    hideLoading();
    if(result.success) {
        showToast('Bot stopped successfully!', 'success');
        setTimeout(() => location.reload(), 1000);
    } else {
        showToast(result.error || 'Failed to stop bot', 'error');
    }
}

// Restart bot
async function restartBot(botId) {
    showLoading();
    const result = await ajax(`api/restart.php?id=${botId}`, 'POST');
    hideLoading();
    if(result.success) {
        showToast('Bot restarted successfully!', 'success');
        setTimeout(() => location.reload(), 1000);
    } else {
        showToast(result.error || 'Failed to restart bot', 'error');
    }
}

// Delete bot
async function deleteBot(botId) {
    confirmDialog('Are you sure you want to delete this bot? This action cannot be undone!', async () => {
        showLoading();
        const result = await ajax(`api/delete.php?id=${botId}`, 'POST');
        hideLoading();
        if(result.success) {
            showToast('Bot deleted successfully!', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(result.error || 'Failed to delete bot', 'error');
        }
    });
}

// ==================== CODE EDITOR ====================

let editor = null;

function initCodeEditor(elementId, language = 'python') {
    if(typeof CodeMirror !== 'undefined') {
        editor = CodeMirror.fromTextArea(document.getElementById(elementId), {
            lineNumbers: true,
            mode: language,
            theme: 'dracula',
            autoCloseBrackets: true,
            matchBrackets: true,
            indentUnit: 4,
            lineWrapping: true,
            tabSize: 4,
            extraKeys: {
                'Ctrl-S': function(cm) {
                    document.querySelector('form').submit();
                }
            }
        });
    }
    return editor;
}

// ==================== TERMINAL ====================

function initTerminal() {
    const input = document.getElementById('terminalInput');
    const output = document.getElementById('terminalOutput');
    
    if(input) {
        input.addEventListener('keypress', async function(e) {
            if(e.key === 'Enter') {
                const command = this.value;
                if(command.trim() === '') return;
                
                output.innerHTML += `<br><span style="color: #ffd700;">${command}</span><br>`;
                
                const result = await ajax('api/terminal-exec.php', 'POST', { cmd: command });
                output.innerHTML += `<span>${result.output || 'Command executed'}</span><br>`;
                
                this.value = '';
                output.scrollTop = output.scrollHeight;
            }
        });
    }
}

// ==================== PREMIUM CHECKOUT ====================

function initRazorpay(plan, amount) {
    const options = {
        key: RAZORPAY_KEY,
        amount: amount * 100,
        currency: 'INR',
        name: SITE_NAME,
        description: plan.toUpperCase() + ' Plan Subscription',
        handler: async function(response) {
            const result = await ajax('checkout.php', 'POST', {
                payment_id: response.razorpay_payment_id,
                plan: plan,
                amount: amount
            });
            if(result.success) {
                showToast('Payment successful! Premium activated.', 'success');
                setTimeout(() => window.location.href = 'dashboard.php', 2000);
            } else {
                showToast('Payment failed! Please try again.', 'error');
            }
        }
    };
    const rzp = new Razorpay(options);
    rzp.open();
}

// ==================== SEARCH ====================

function initSearch() {
    const searchInput = document.getElementById('searchInput');
    if(searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const items = document.querySelectorAll('.searchable-item');
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if(text.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }
}

// ==================== TOOLTIPS ====================

function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(el => {
        el.addEventListener('mouseenter', function(e) {
            const tooltip = document.createElement('div');
            tooltip.className = 'custom-tooltip';
            tooltip.textContent = this.dataset.tooltip;
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            
            this.addEventListener('mouseleave', () => tooltip.remove());
        });
    });
}

// ==================== DARK MODE ====================

function toggleDarkMode() {
    const body = document.body;
    const isDark = body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDark);
}

function loadDarkModePreference() {
    const isDark = localStorage.getItem('darkMode') === 'true';
    if(isDark) document.body.classList.add('dark-mode');
}

// ==================== INITIALIZATION ====================

document.addEventListener('DOMContentLoaded', function() {
    // Load system status every 10 seconds
    if(document.getElementById('systemStatus')) {
        loadSystemStatus();
        setInterval(loadSystemStatus, 10000);
    }
    
    // Initialize tooltips
    initTooltips();
    
    // Initialize search
    initSearch();
    
    // Load dark mode preference
    loadDarkModePreference();
    
    // Add CSRF token to all forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        if(!form.querySelector('input[name="csrf_token"]')) {
            const token = document.createElement('input');
            token.type = 'hidden';
            token.name = 'csrf_token';
            token.value = document.querySelector('meta[name="csrf-token"]')?.content || '';
            form.appendChild(token);
        }
    });
});